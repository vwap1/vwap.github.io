# Renko_2.0_Offline
Biblioteca MQ5 para gráfico Renko

## Imagens
![grafico1](https://c.mql5.com/18/75/RenkoOffline_2.0_Parameters__1.png)

![grafico2](https://c.mql5.com/18/66/Renko_2.0_Offline_5Pips__1.png)
